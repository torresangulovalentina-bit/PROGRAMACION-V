import dotenv from 'dotenv';
dotenv.config();
import express from 'express';
import cors from 'cors';
import mysql from 'mysql2/promise';

const app = express();
app.use(cors());
app.use(express.json());

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'proyectos',
  port: 3306,
  connectionLimit: 10
});

app.get('/api/ciudades', async (req,res)=>{
  const [rows] = await pool.query('SELECT * FROM ciudades');
  res.json(rows);
});
app.get('/api/clientes', async (req,res)=>{
  const [rows] = await pool.query('SELECT * FROM clientes');
  res.json(rows);
});
app.get('/api/oficinas', async (req,res)=>{
  const [rows] = await pool.query('SELECT * FROM oficinas');
  res.json(rows);
});
app.get('/api/proyectos', async (req,res)=>{
  const [rows] = await pool.query('SELECT * FROM proyectos');
  res.json(rows);
});

app.listen(3000, ()=> console.log('FIX corriendo en http://localhost:3000 - Prueba /api/ciudades'));